# YTVideoOverlay

A helper tweak to add buttons to iOS YouTube's video player overlay.

See `Template.x.example` for code example and `control.example` for debian package control file example.
