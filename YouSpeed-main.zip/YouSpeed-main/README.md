# YouSpeed

- Views and changes video speed in YouTube app from the video overlay
- Adds more video speeds to choose from
- Changes the default video speed selector to a slider

## Prerequisites

[YTVideoOverlay](https://github.com/PoomSmart/YTVideoOverlay).
